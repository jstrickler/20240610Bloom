for n in range(0, 32):
    print(f"{n:2d} {2 ** n:10d}")

