import sys

print(f"sys.argv: {sys.argv}\n")


animal = sys.argv[1]  # First command line parameter
print(f"animal: {animal}")

