a = "123"
b = 456
result1 = a + str(b) # convert int to str and concatenate
print(f"result1: {result1}")

result2 = int(a) + b  # convert str to int and add
print(f"result2: {result2}")
