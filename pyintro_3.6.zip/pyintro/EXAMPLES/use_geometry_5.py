from geometry import circle_area as c_area, rectangle_area as r_area, square_area as s_area

a1 = c_area(8)
a2 = r_area(10, 12)
a3 = s_area(7.9)
print(a1, a2, a3)
