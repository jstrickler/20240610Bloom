regex = r"\w+\s+\w+"
file_path = r"c:\temp"
message = r"please put a newline character (\n) after each line"

print(regex)
print(file_path)
print(message)
