
x = 5
y = "cheese"

z = x + y  # Adding a string to an int raises TypeError
